
########################################
################ Import ################
########################################
from UI_IHM import Ui_MainWindow
from ThreadCompute import ThreadCompute
from plotter import CustomWidget
from treatment import ksi,amplitudeTreatment
import sys
import time
import re

from PyQt5 import QtWidgets

from PyQt5.QtCore import * 
from PyQt5.QtGui import * 
from PyQt5.QtWidgets import * 

from PyQt5.QtCore import QIODevice
from PyQt5.QtSerialPort import QSerialPort, QSerialPortInfo
from PyQt5.QtCore import QTimer,QDateTime



def findPort():
    # Find first available EiBotBoard by searching USB ports.
    # Return serial port object.
    try:
        from serial.tools.list_ports import comports
    except ImportError:
        return None
    if comports:
        com_ports_list = list(comports())

        ebb_port = None
        for port in com_ports_list:
            return port[0]
 

port=findPort()
print(port)
#Création de la classe principale

def displayData(ihm ,data, data_x):

    print("NB_ACQUIRING = ")   
    print(">>"+str(len(data)))
    print(">>"+str(len(data_x)))
    print(">>"+str(len(ihm.data_ignored)))
    print(">>"+str(ihm.decrement))
    print("UPDATING GRAPHS")
    ihm.ui.widget.update(data,data_x)
    #while ihm.is_paused :
        #time.sleep(0)
    #ihm.ui.frequenciel_widget.update(data,data_x)

    #ihm.data=[]
    #ihm.data_x=[]


    time.sleep(0.5)

class MainWindow(QtWidgets.QMainWindow):

    #Constructeur
    def __init__(self):

        
        super(MainWindow, self).__init__()

        #Data Variable
        self.full_couple_data=[]
        self.data = []
        self.data_x = []
        self.data_ignored =[]

        #instant split par amplitude pour régime forcee
        self.amplitudeData = []

        #Input IHM
        self.timer = 5
        self.timerAcqui = 5
        self.freq = 100
        self.mode = 1
        self.plage="1-1-1-1-1-1-1-1-1-1"
        self.plageList=[1,1,1,1,1,1,1,1,1,1]
        self.plageAmpl=[]
        self.plageVitesse=[0.25,0.5,0.75,1.0,1.25,1.5,1.75,2.0,2.25,2.5]
        self.plageSelected=[]
        #intern Variable
        self.tenth = 0
        self.start=True
        self.first=True
        self.decrement=0

        #treatment Variable
        self.state=False


        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        self.currentIndexData = 0
        self.port = str(findPort())
        self.baudrate = 115200

        self.timer_freq=QTimer()


        #création d'un objet serial et appel automatique 



        #self.thread = ThreadCompute(0, "Callback_thread", self ,self.data, self.data_x, displayData)
        #self.is_paused = True
        #self.thread.start()
        """
        CONNECTIONS + INIT
        """
        #Slider /Box Update

        self.ui.temps_Slider.setValue(self.timer)
        self.ui.temps_textBrowser.setText(str(self.timer))
        self.ui.temps_Slider_2.setValue(self.timerAcqui)
        self.ui.temps_textBrowser_2.setText(str(self.timerAcqui))

        self.ui.freq_Slider.setValue(self.freq)
        self.ui.freq_textBrowser.setText(str(self.freq))
        self.ui.temps_Slider.valueChanged.connect(self.update_timer)
        self.ui.temps_Slider_2.valueChanged.connect(self.update_tempsAcqui)
        self.ui.freq_Slider.valueChanged.connect(self.update_freq)
        self.ui.ports_box.currentTextChanged.connect(self.update_port)
        self.ui.comboBox.currentTextChanged.connect(self.update_mode)
        self.ui.comboBox_forcee.currentTextChanged.connect(self.update_window_forcee)

        #button connect
        self.ui.run_Button.clicked.connect(self.run_click)
        self.ui.stop_Button.clicked.connect(self.stop_click)
        self.ui.stop_Button.setEnabled(False)
        self.ui.exit_Button.clicked.connect(self.exit_click)
        self.ui.reset_Button.clicked.connect(self.reset_click)
        self.ui.electroaiment_Button.clicked.connect(self.electroaiment_click)
        self.ui.connectButton.clicked.connect(self.connect_click)

        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.InputStackedWidget.setCurrentIndex(0)

        #Menu connect
        self.ui.menuHelp.triggered.connect(self.help_click)

        #checkbox
        self.ui.checkBox_10.clicked.connect(self.update_plages)
        self.ui.checkBox_20.clicked.connect(self.update_plages)
        self.ui.checkBox_30.clicked.connect(self.update_plages)
        self.ui.checkBox_40.clicked.connect(self.update_plages)
        self.ui.checkBox_50.clicked.connect(self.update_plages)
        self.ui.checkBox_60.clicked.connect(self.update_plages)
        self.ui.checkBox_70.clicked.connect(self.update_plages)
        self.ui.checkBox_80.clicked.connect(self.update_plages)
        self.ui.checkBox_90.clicked.connect(self.update_plages)
        self.ui.checkBox_100.clicked.connect(self.update_plages)
        """
        PLOTTING
        """

    def writeData(self):
        string="{},{},{}".format(self.mode,str(self.timerAcqui).zfill(3),self.plage)

        #string=str(self.mode) # MODE 0 = simple oscillation du reglet, pas de moteur
        print(string)
        print(self.serial.write(bytes(string,'utf-8')))

    #Fonction appelée dès reception d'octets
    #callbackReading
    def readData(self):
        if self.serial.canReadLine():
            read_data = str(self.serial.readLine())
            #print(read_data)
            couple_data=read_data[2:][:-5].split(',')
            #self.full_couple_data.append(couple_data)
            print(couple_data)
        else : return
        try :
            if int(couple_data[1])  and int(couple_data[0]) and len(couple_data)==2: #and int(couple_data[0]) and float(couple_data[1])
                if int(couple_data[0])>5000:
                    return
                if self.tenth<5:
                    self.tenth+=1
                elif self.start==True:
                    if self.first:
                        self.decrement=int(couple_data[1])
                        #print(self.decrement)

                        self.first=False

                    instant=(int(couple_data[1]))#-self.decrement
                    print(instant)
                    if instant <0:
                        return
                    self.data_x.append(instant/1000)
                    self.data.append(float(couple_data[0]))
                    #print("{} {}".format(instant , float(couple_data[0])) )
                    if self.mode==1:
                        if (instant >=self.timer*1000):
                            self.start=False
                            self.state=True
                            self.stop_click()

                    elif self.mode==2:
                        if instant >=(self.timerAcqui*1000)*len(self.plageList):#
                            #print("stop mode 1")
                            self.start=False
                            self.state=True
                            self.stop_click()

                #time.sleep(freq/100)
            else :
                self.data_ignored.append(couple_data)
        except :
            self.data_ignored.append(couple_data)

    def connect_click(self):
        #Definition du port série 
        self.serial = QSerialPort(self.port,baudRate=self.baudrate) #, readyRead=self.callbackReading)

        #Connexion et barre de status
        result = self.serial.open(QIODevice.ReadWrite) #Tentative de connexion
        if(result):
            self.statusBar().showMessage("Le port '"+self.port+"' est ouvert ("+str(self.baudrate)+")")
        else:
            self.statusBar().showMessage("Impossible d'ouvrir le port '"+str(self.port)+"'" )

    def run_click(self):
        self.reset()
        #self.is_paused=False
        self.ui.run_Button.setEnabled(False)
        self.ui.stop_Button.setEnabled(True)

        #envois des paramètres
        self.writeData()

        #print("paramètres envoyés")

        #lancement de la fonction qui boucle dès la réception d'octets
        self.serial.readyRead.connect(self.readData)

        self.thread.start()

    def stop_click(self):
        print(self.serial.write(bytes("3,001,0-0-0-0-0-0-0-0-0-0",'utf-8')))
        self.ui.run_Button.setEnabled(True)
        self.ui.stop_Button.setEnabled(False)
        self.serial.close()
        self.thread.stop_event.set()
        #self.is_paused=True
        with open('Data_no_motor.txt', 'w') as f:
            for x,y in zip(self.data_x, self.data):
                f.write(str(x)+" , "+str(y)+ "\n")
        
        if self.state:
            if self.mode==1:
                self.treatmentMode0()
            elif self.mode==2:
                self.treatmentMode1()

    def reset_click(self):
        self.stop_click()
        self.__init__()

    def electroaiment_click(self):
        print(self.serial.write(bytes("0,001,0-0-0-0-0-0-0-0-0-0",'utf-8')))

    def reset(self):
        self.data=[]
        self.data_x=[]
        #self.ui.widget.clean()
        self.tenth = 0
        self.start=True
        self.first=True
        self.thread = ThreadCompute(0, "Callback_thread", self ,self.data, self.data_x, displayData)
        """
        self.full_couple_data=[]
        self.data = []
        self.data_x = []
        self.start=True
        self.first=True
        self.state=False
        """

    def treatmentMode0(self):
        print("traitement Mode 0")
        ksi(self)
        #print(self.data)
        #print(self.data_x)
        self.ui.frequenciel_widget.update(self.data,self.data_x)

    def treatmentMode1(self):
        print("treatment Mode 1")
        self.ui.freq_forcee_widget.update(self.data,self.data_x)
        amplitudeTreatment(self)
        print(self.plageAmpl)
        print(self.plageSelected)
        self.ui.amplitude_widget.update(self.plageAmpl,self.plageSelected)
        self.ui.Resonance_textBrowser.setText(str(max(self.plageAmpl)))

        

    def exit_click(self):
        #self.is_paused=False
        try:
            self.thread.stop_event.set()
        except:
            pass
        QCoreApplication.instance().exit()
        
    def update_timer(self,value):
        self.timer=value
        self.ui.temps_textBrowser.setText(str(self.timer))
        print(value)

    def update_tempsAcqui(self,value):
        self.timerAcqui=value
        self.ui.temps_textBrowser_2.setText(str(self.timerAcqui))
        print(value)

    def update_freq(self,value):
        self.freq=value
        self.ui.freq_textBrowser.setText(str(self.freq))
        print(value)
        
    def update_port(self,value):
        self.port=value
        print(value)

    def update_plages(self,value):
        p=[]
        self.plageSelected=[]
        self.plage=""
        self.plageList=[]
        p.append(int(self.ui.checkBox_10.isChecked()))
        p.append(int(self.ui.checkBox_20.isChecked()))
        p.append(int(self.ui.checkBox_30.isChecked()))
        p.append(int(self.ui.checkBox_40.isChecked()))
        p.append(int(self.ui.checkBox_50.isChecked()))
        p.append(int(self.ui.checkBox_60.isChecked()))
        p.append(int(self.ui.checkBox_70.isChecked()))
        p.append(int(self.ui.checkBox_80.isChecked()))
        p.append(int(self.ui.checkBox_90.isChecked()))
        p.append(int(self.ui.checkBox_100.isChecked()))
        for elem in p: 
            self.plage+=str(elem)
            self.plage+="-"
            if elem==1:
                self.plageList.append(elem)
        self.plage=self.plage[:-1]
        #print(self.plage)
        vitplage=self.plage.split('-')
        print(vitplage)
        #print(vitplage)
        #print(self.plageVitesse)
        p=0
        for elem in vitplage:
            add=float(elem)*self.plageVitesse[p]
            if float(add)!=0:
                self.plageSelected.append(add)
            p+=1
        print(self.plageSelected)
        #print(len(self.plageList))
        #same for others

        pass

    def update_mode(self,value):
        if value =="Régime d'oscillations libres":
            self.ui.stackedWidget.setCurrentIndex(0)
            self.ui.InputStackedWidget.setCurrentIndex(0)
            #self.ui.run_Button.setEnabled(False)
            self.mode=1
        elif value=="Régime d'oscillations forcées":
            self.ui.stackedWidget.setCurrentIndex(1)
            self.ui.InputStackedWidget.setCurrentIndex(1)
            #self.ui.run_Button.setEnabled(True)
            self.mode=2
        print("Mode ",self.mode)

    def update_window_forcee(self, value):
        if value == "Global":
            self.ui.stackedWidget_forcee.setCurrentIndex(0)
        elif value == "10Hz":
            self.ui.stackedWidget_forcee.setCurrentIndex(1)

    def help_click(self):
        #print("test")
        w = QMessageBox(self)
        w.setWindowTitle("Help Menu")
        #w.resize(640, 480)
        w.setText("Cet IHM permet de piloter l'oscillation du Réglet sous deux Régimes :\n"+
            "   -Régime d'oscillations Libres\n"+
            "Connecter au port avec le bouton Connect\n"+
            "Activer l'électroaimant et bloquer le réglet (Bouton Electroaimant)\n"+
            "Selectionner une durée d'acquisition\n"+
            "Le bouton RUN permet de lancer l'acquisition\n"+
            "Les données sont traités et enregistrés dans un .txt après acquisition\n"+
            "   -Regime d'oscillations Forcées\n"+
            "Connecter au port avec le bouton Connect\n"+
            "Selectionner une durée d'acquisition par plage\n"+
            "Selectionner les vitesses moteurs\n")
        w.exec_()

        # label = QTextBrowser(w)
        # label.setText("Help\n instructions: \n")
        # label.adjustSize()
        # label.move(30, 30)
        
        # self.ui.textEdit = QtWidgets.QTextEdit(self.ui.Control_panel)
        # self.ui.textEdit.setReadOnly(True)
        # self.ui.textEdit.append("test")
        # self.ui.textEdit.setGeometry(QRect(18, 130, 261, 41))
        # pass
        # self.ui.

############################################
############ MAIN ##########################
############################################

def main():

    app = QtWidgets.QApplication(sys.argv) #Creation de l'application
    ihm = MainWindow()                      #Appel de notre classe principale
    ihm.show()                              #Affichage de l'interface
    sys.exit(app.exec_())                   #Loop

if __name__ == "__main__":              
    main()