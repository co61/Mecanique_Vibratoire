import pyqtgraph as pg
from pyqtgraph.Qt import QtCore, QtGui
import numpy as np


class  CustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    ptr1 = 0
    def __init__(self, parent=None, **kwargs):
        #super(CustomWidget,self).__init__(*args,**kwargs)
        pg.GraphicsWindow.__init__(self, **kwargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        self.p1 = self.addPlot(labels =  {'left':'Voltage', 'bottom':'Time'})
        self.data_x = []
        self.data_y = []
        self.curve1 = self.p1.plot(self.data_x,self.data_y, pen=(3,3))
        
        #self.p1 = self.addPlot(labels =  {'left':'Voltage', 'bottom':'Time'})
        #self.p1.plot([1,2,3,4,5,6,7,8,9,10], [30,32,34,32,33,31,29,32,35,45])

    def update(self,new_x, new_y):

        self.data_x = new_x
        self.data_y = new_y
        self.curve1.setData( self.data_y,self.data_x)


    def clean(self):
        #self.curve1.setData([0],[0])
        
        #self.removeItem(self.p1)
        #self.curve1.remove()
        #self.p1 = self.addPlot(labels =  {'left':'Voltage', 'bottom':'Time'})
        #self.curve1 = self.p1.plot([],[], pen=(3,3))
        print("clean main widget")
        pass


class FreqCustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    #ptr1 = 0
    def __init__(self, parent=None, **kargs):
        pg.GraphicsWindow.__init__(self, **kargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        p1 = self.addPlot(labels =  {'left':'', 'bottom':'Hz'})
        
        aa = []
        tt= []
        self.curve1 = p1.plot(aa,tt, pen=(3,3))
        p1.setRange(xRange=[0,5])
    def update(self,new_y, new_x):
        aa = new_x
        tt = new_y
        #affichage des fréquences
        AA = np.fft.fft(aa)
        N = len(aa)
        k = np.arange(0,N,1)
        Te = 0.003
        deltaF = 1/N/Te
        freq = k*deltaF
        freq_shift = freq-1/Te/2
        A2 = np.fft.fftshift(AA)
        self.curve1.setData( freq_shift,abs(A2))

    def clean(self):
        self.curve1.setData([],[])
        pass

class FreqForceeCustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    #ptr1 = 0
    def __init__(self, parent=None, **kargs):
        pg.GraphicsWindow.__init__(self, **kargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        p1 = self.addPlot(labels =  {'left':'', 'bottom':'Hz'})
        
        aa = []
        self.data_y = []
        self.curve1 = p1.plot(aa,self.data_y, pen=(3,3))
        p1.setRange(xRange=[0,5])
    def update(self,new_y, new_x):
        aa = new_x
        self.data_y = new_y
        """
        #affichage des fréquences
        AA = fft(aa)
        N = len(aa)
        k = np.arange(0,N,1)
        Te = 0.003
        deltaF = 1/N/Te
        freq = k*deltaF
        freq_shift = freq-1/Te/2
        A2 = fftshift(AA)
        self.curve1.setData( freq_shift,abs(A2))
        """
    def clean(self):
        self.curve1.setData([],[])
        pass

class EtaCustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    #ptr1 = 0
    def __init__(self, parent=None, **kargs):
        pg.GraphicsWindow.__init__(self, **kargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        p1 = self.addPlot(labels =  {'left':'Eta', 'bottom':'Time'})
        
        aa = []
        self.data_y = []
        self.curve1 = p1.plot(aa,self.data_y, pen=(3,3))
        p1.setRange(xRange=[0,5])
    def update(self,new_y, new_x):
        aa = new_x
        self.data_y = new_y
    def clean(self):
        self.curve1.setData([],[])
        pass

class PositionCustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    #ptr1 = 0
    def __init__(self, parent=None, **kargs):
        pg.GraphicsWindow.__init__(self, **kargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        p1 = self.addPlot(labels =  {'left':'', 'bottom':'Time'})
        
        aa = []
        self.data_y = []
        self.curve1 = p1.plot(aa,self.data_y, pen=(3,3))
        p1.setRange(xRange=[0,5])
    def update(self,new_y, new_x):
        aa = new_x
        self.data_y = new_y
    def clean(self):
        self.curve1.setData([],[])
        pass

class AmplitudeCustomWidget(pg.GraphicsWindow):
    pg.setConfigOption('background', 'w')
    pg.setConfigOption('foreground', 'k')
    def __init__(self, parent=None, **kargs):
        pg.GraphicsWindow.__init__(self, **kargs)
        self.setParent(parent)
        self.setWindowTitle('pyqtgraph example: Scrolling Plots')
        p1 = self.addPlot(labels =  {'left':'Amplitude Résonateur', 'bottom':'Fréquence Moteur'})
        
        aa = []
        self.data_y = []
        self.curve1 = p1.plot(aa,self.data_y, pen=(3,3))
        

    def update(self,new_y, new_x):
        self.curve1.setData(new_y, new_x)

