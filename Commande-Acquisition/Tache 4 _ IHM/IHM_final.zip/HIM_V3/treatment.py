import numpy as np

def ksi(self):
	#On va chercher à obtenir l'amortissement Ksi à partir des données à l'aide du décrément logarithmique
	#Un filtrage est peut être nécessaire
	aa=self.data
	tt=self.data_x
	#On cherche deux maximum consécutifs:
	maxA = aa[0]
	maxB = aa[0]
	ttA = 0        #indice temporel de maxA
	ttB = 0
	i=1


	while i<len(aa):
	    if maxA < aa[i] :
	        maxA = aa[i]
	        ttA = tt[i]
	    elif aa[i]<200:
	        break
	    i+=1
	    
	#Pour trouver le 2e maximum, il faut trouver le minimum entre les 2
	minC = maxA
	ttC = 0
	while i<len(aa):
	    if minC > aa[i]:
	        minC = aa[i]
	        ttC = tt[i]  
	    elif aa[i]>400:
	    	break
	    i+=1
	
	while i < len(aa):
	    if maxB < aa[i]:
	        maxB = aa[i]
	        ttB = tt[i]
	    i+=1

	f0 = 4
	w0 = 2*np.pi*f0
	n=1
	T = (ttB - ttA) /n
	delta = (maxA-maxB)/maxA #on normalise pour obtenir un résultat plus cohérent
	self.ksi = delta/w0/n/T

	print("ksi = ", self.ksi)

	string ="maxA = " +  str(maxA) +  " at t=" + str(ttA) + "\n" + "minC = " +  str(minC) + " at t=" + str(ttC) + "\n" + "maxB = " +  str(maxB) +  " at t=" +  str(ttB)
	#print(" maxA = ", maxA, " at t=", ttA,"\n","minC = ", minC, " at t=", ttC,"\n","maxB = ", maxB, " at t=", ttB)
	print(string)
	self.ui.maxmin_label.setText(string)
	self.ui.ksi_textBrowser.setText(str(self.ksi))

def ampl_intern(aa):
	center=np.mean(aa)
	max=center
	min=center
	ampl=[]
	firstPeriod=True
	for elem in aa :
	    if elem > max :
	        max=elem
	    if elem < min :
	        min=elem
	    if elem > center and firstPeriod:
	        ampl.append(max-center)
	        firstPeriod=False
	    if elem <center and not firstPeriod:
	        firstPeriod=True
	        ampl.append(center-min)
	return np.mean(ampl[0:-1])
	#print("amplitude : ",np.mean(ampl[int(len(ampl)/3):-1]))

def amplitudeTreatment(self):
	indexList=[]
	for elem in self.data_x:
		#print((elem*1000) % (self.timerAcqui*1000))
		if round((elem*1000) % (self.timerAcqui*1000)) == 0 or self.data_x.index(elem)==10:#or int(elem)==30
			#print(elem*100
			index=self.data_x.index(elem)
			#print(index)
			if indexList:
				if index-indexList[-1]>10 :
					indexList.append(index)
			else :
				indexList.append(index)
	#print("indexlist",indexList)
	x=1
	#print(indexList[0:2])
	#print(self.data[indexList[0]:indexList[1]])
	#print(ampl_intern(self.data[indexList[0]:indexList[1]]))
	
	for index in indexList:
		try:
			amplitude=ampl_intern(self.data[index:indexList[x]])
			#print(amplitude)
			self.plageAmpl.append(amplitude)
		except:
			pass
			#print("end of list")
			#end of list
		x+=1
	#print(self.plageAmpl)
	

