import time
import threading

class ThreadCompute (threading.Thread):

    """!
    """
    def __init__(self, threadID, threadName, ihm, data, data_x, function=None):

        threading.Thread.__init__(self)

        self.threadID = threadID
        self.threadName = threadName
        self.__function = function

        #Args
        self.arg1 = data
        self.arg2 = data_x
        self.ihm = ihm
        self.stop_event=threading.Event()
    """!
    @return
    """
    def run(self):

        print("Starting " + self.threadName+"\n")

        while(1):
            self.__function(self.ihm ,self.arg1, self.arg2)
            if self.stop_event.is_set():
                self.__function(self.ihm, self.arg1, self.arg2)
                break
        print("Exiting " + self.threadName)